--Some info about the bullets
bulletBig_radius	= 6
objectMultiplier	= 40
bulletLifeSpan		= 4

--Set Bullets' Table
bullets = {}

function fireBullet(startX, startY, newAimPosX, newAimPosY, world)

	local body 			= love.physics.newBody(world, (startX+newAimPosX*objectMultiplier), (startY-newAimPosY*objectMultiplier), "dynamic")
	local bulletShape 	= love.physics.newCircleShape( bulletBig_radius )
	local fixture 		= love.physics.newFixture(body, bulletShape)
	local creation_time = love.timer.getTime()
	local bulletSpeed 	= 240

	fixture:setRestitution(1)
	body:setLinearDamping(0)
		
	fixture:setUserData("Bullet"..tostring(creation_time))

	body:applyLinearImpulse(newAimPosX*bulletSpeed, newAimPosY*-bulletSpeed)
	body:setBullet(true) 

	table.insert(bullets, {fixture = fixture, body = body, creation_time = creation_time})

end

function handleBullet()

	for i,v in pairs(bullets) do

		if (v.creation_time + bulletLifeSpan <= love.timer.getTime( )) then

			v.body:destroy()
			table.remove(bullets, i)

		end

	end

end

function drawBullet()
	
	for i,v in pairs(bullets) do

		love.graphics.setColor(255, 255, 255, 255)
		love.graphics.draw(bulletBig, v.body:getX()-8, v.body:getY()-8)
		
	end

end

function debugBullet()

	for i,v in pairs(bullets) do

		love.graphics.setColor(255, 255, 0, 255)
		love.graphics.circle("line", v.body:getX(), v.body:getY(), 3)
		love.graphics.setColor(255, 255, 255, 255)

	end

end

function pauseBullet()
	for i,v in pairs(bullets) do

		v.creation_time = v.creation_time + (love.timer.getTime( ) - v.creation_time)

	end
end