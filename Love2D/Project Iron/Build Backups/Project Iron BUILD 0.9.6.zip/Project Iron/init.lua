--Load application extentions
require "lib/LoveFrames"
require "lib/TEsound"
sti = require "lib/STI"

--Mount the other components
require "conf"
require "globalvars"
require "keybinds"
require "sound"
require "readwrite"
require "assets"
require "microfunctions"

require "players"
require "physics"

require "game"

require "inputhandling"
require "bullets"
require "draw"
require "controls"

require "menu"