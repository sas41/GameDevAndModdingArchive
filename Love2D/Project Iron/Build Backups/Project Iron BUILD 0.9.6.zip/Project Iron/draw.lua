--This one right here draws the map and the whole world...
function drawWrold()

	if graphicsScaling == true then

		if defaultResolutionW/mapSizeX < defaultResolutionH/mapSizeY then
	
			local mapRatioX			= (defaultResolutionW/mapSizeX)
			local mapRatioY			= (defaultResolutionH/mapSizeY)
			local translatedMap		= math.floor(mapSizeY*mapRatioX)
			local mapPushY			= math.floor((defaultResolutionH/2)-((translatedMap)/2))

			love.graphics.translate(0, mapPushY)
			map:draw(mapRatioX, mapRatioX)

		elseif defaultResolutionW/mapSizeX >= defaultResolutionH/mapSizeY then

			local mapRatioX			= (defaultResolutionW/mapSizeX)
			local mapRatioY			= (defaultResolutionH/mapSizeY)
			local translatedMap		= math.floor(mapSizeX*mapRatioY)
			local mapPushX			= math.floor((defaultResolutionW/2)-((translatedMap)/2))
			
			love.graphics.translate(mapPushX, 0)
			map:draw(mapRatioY, mapRatioY)

		end

	else

		love.graphics.translate((defaultResolutionW/2)-mapSizeX/2, (defaultResolutionH/2)-mapSizeY/2)
		map:draw()

	end

end

--Set Collision debugging color and turn the function on
function debugWorld()

	love.graphics.setColor(255, 0, 0, 255)
	map:drawWorldCollision(collision)
	love.graphics.setColor(255, 255, 255, 255)

end