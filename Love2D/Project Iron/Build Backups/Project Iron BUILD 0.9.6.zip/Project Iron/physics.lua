function beginContact(a, b)

	if a:getUserData() == "Player" and string.sub(b:getUserData(), 1, 6) == "Bullet" then

		local getBulletTime 	= string.sub(b:getUserData(), 7)

		if player1Active == true and a:getBody() == spriteLayer.player1.body then
			player1Active = false
			spriteLayer.player1.body:destroy()
		end

		if player2Active == true and a:getBody() == spriteLayer.player2.body then
			player2Active = false
			spriteLayer.player2.body:destroy()
		end

		if player3Active == true and a:getBody() == spriteLayer.player3.body then
			player3Active = false
			spriteLayer.player3.body:destroy()
		end

		if player4Active == true and a:getBody() == spriteLayer.player4.body then
			player4Active = false
			spriteLayer.player4.body:destroy()
		end

		for i,v in pairs(bullets) do

			if (tostring(v.creation_time)) == getBulletTime then

				v.body:destroy()
				table.remove(bullets, i)

			end

		end

	end

end

function endContact()

end

function preSolve()

end

function postSolve ()

end