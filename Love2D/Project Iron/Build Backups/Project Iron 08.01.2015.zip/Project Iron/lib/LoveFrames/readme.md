# Love Frames

## Information

Love Frames is a GUI library for [L�VE](https://love2d.org/). Information on installation and usage can be found in the [documentation](http://nikolairesokav.com/projects/loveframes/docs). A demo of the library can be found at: http://nikolairesokav.com/projects/loveframes/

## License

Love Frames is licensed under the zlib/libpng license. For more information, please read license.txt.

## Credits

Created by Kenny Shields

**Third-Party Libraries**

- middleclass by kikito - https://github.com/kikito/middleclass
