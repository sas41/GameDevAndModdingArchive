function love.conf(configure)
	configure.window.icon = "assets/sprites/players/RedTank.png"
	configure.window.vsync = false
	configure.window.fsaa = 0
	configure.window.display = 1
	configure.window.highdpi = true
	configure.window.srgb = true
	configure.modules.joystick = true
	configure.modules.thread = true
end